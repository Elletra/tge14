//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#if 0

// Core strings are out of date so this code is currently disabled.

#include "i18n/CoreStrings.h"

#ifndef _I18N_H_
#define _I18N_H_

#define _L(x)		(getCoreString(x))

// Protos
extern const UTF8 *getCoreString(S32 id);

#endif // _I18N_H_

#endif